package com.ronglian.lakehouse.main.process.dwd;

import com.ronglian.lakehouse.main.util.KafkaUtil;
import com.ronglian.lakehouse.main.util.MysqlUtil;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableResult;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;

/**
 * @author m1ggle
 * 交易域加购事务事实表
 * 提取加购操作生成结构表，并将字典表中的相关维度退化到加购表中，写出到kafka对用主题，
 * kafka主题为 dwd_trade_cart_add
 *
 */
public class DwdTradeCartAdd {
    public static void main(String[] args) throws Exception {
        // todo 1.创建执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 通用配置
        env.setParallelism(1);
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);
//       //开启checkpoint
//        env.enableCheckpointing(5*60000L, CheckpointingMode.EXACTLY_ONCE);
//        env.getCheckpointConfig().setCheckpointTimeout(10*60000L);
//        env.getCheckpointConfig().setMaxConcurrentCheckpoints(2);
//        //重启策略
//        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3,5000L));
//        //设置后端状态
//        env.setStateBackend(new HashMapStateBackend());
//        env.getCheckpointConfig().setCheckpointStorage("hdfs://kubemaster:8020/flink/check_point");
        //设置本地运行用户
        System.setProperty("HADOOP_USER_NAME","hadoop");
        // todo 2.使用ddl方式读取 base_db 主题的数据创建表
        tableEnv.executeSql(KafkaUtil.getTopicDb("DWD_TRADE_CART_ADD_GROUP"));
        // todo 3.过滤出加购数据
        TableResult cartAddTable = tableEnv.executeSql("select  " +
                " data['id'] as id, " +
                " data['user_id'] as user_id, " +
                " data['sku_id'] as sku_id, " +
                " data['cart_price'] as cart_price, " +
                " if(`type` = 'insert',data['sku_num'],cast( cast(data['sku_num'] as int) > cast( `old`[sku_num] as int ) as string)) as sku_num, " +
                " data['sku_name'] as sku_name, " +
                " data['is_checked'] as is_checked, " +
                " data['create_time'] as create_time, " +
                " data['operate_time'] as operate_time, " +
                " data['is_ordered'] as is_ordered, " +
                " data['order_time'] as order_time, " +
                " data['source_type'] as source_type, " +
                " data['source_id'] as source_id, " +
                " `pt` " +
                "from topic_db " +
                "where `database` = 'gmall' " +
                "and `table` = 'cart_info' " +
                "and `type` = 'insert' " +
                "or (`type` = 'update'  " +
                "   and `old`[sku_num] is not null  " +
                "   and cast(data['sku_num'] as int) > cast( `old`[sku_num] as int ))");
        // todo 4.读取MySQL的 base_dic 表作为 lookup 表
        tableEnv.executeSql(MysqlUtil.getBaseDicLookUpDDL());
        // todo 5.关联两张表
        tableEnv.createTemporaryView("cart_info", (Table) cartAddTable);
        Table cartAddWithDicTable = tableEnv.sqlQuery("select   " +
                "    ci.id,  " +
                "  ci.user_id,  " +
                "  ci.sku_id,  " +
                "  ci.cart_price,  " +
                "  ci.sku_num,  " +
                "  ci.sku_name,  " +
                "  ci.is_checked,  " +
                "  ci.create_time,  " +
                "  ci.operate_time,  " +
                "  ci.is_ordered,  " +
                "  ci.order_time,  " +
                "  ci.source_type as source_type_id,  " +
                "  dic.dic_name as source_type_name,  " +
                "  ci.source_id  " +
                "from cart_info ci   " +
                "join base_dic dic for system_time as of ci.pt as dic  " +
                "on ci.source_type = dic.dic_code");
        // todo 6.使用ddl方式创建 加购事实表
        tableEnv.executeSql("create table dwd_cart_add(  " +
                "  id STRING,  " +
                "  user_id STRING,  " +
                "  sku_id STRING,  " +
                "  cart_price STRING,  " +
                "  sku_num STRING,  " +
                "  sku_name STRING,  " +
                "  is_checked STRING,  " +
                "  craete_time STRING,  " +
                "  operate_time STRING,  " +
                "  is_ordered STRING,  " +
                "  order_time STRING,  " +
                "  source_type_id STRING,  " +
                "  source_type_name STRING,  " +
                "  source_id  STRING  " +
                ")" + KafkaUtil.getKafkaSinkDdl("dwd_trade_cart_add"));
        // todo 7.将数据写出
        tableEnv.executeSql("insert into dwd_cart_add select * from " + cartAddWithDicTable).print();
        // todo 8.启动任务
        env.execute("dwd_trade_cart_add");
    }
}
