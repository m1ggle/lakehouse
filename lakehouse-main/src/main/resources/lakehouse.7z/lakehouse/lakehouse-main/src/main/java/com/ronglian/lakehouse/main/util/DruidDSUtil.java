package com.ronglian.lakehouse.main.util;

import com.alibaba.druid.pool.DruidDataSource;

public class DruidDSUtil {

    public static DruidDataSource createDataSource(){

        return null;
    }
}
