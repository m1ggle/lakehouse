package com.ronglian.lakehouse.main.process.dwd;

/**
 * @author m1ggle
 * 交易域订单预处理表
 * 订单明细表和取消订单明细表的额数据来源，表结构都相同，差别只在业务过程和过滤条件
 * 为了减少重复计算，将两张表公共的关联过程提取出来，形成订单预处理表。
 * 关联订单明细表、订单表、订单明细活动关联表，订单明细优惠券关联表四张事实业务表和字典表（维度业务表）形成订单预处理博鳌
 * 写入到kafka
 */
public class DwdTradeOrderPreProcess {
}
