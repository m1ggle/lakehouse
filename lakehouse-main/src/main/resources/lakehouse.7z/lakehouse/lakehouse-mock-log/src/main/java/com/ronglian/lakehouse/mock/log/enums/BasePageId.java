package com.ronglian.lakehouse.mock.log.enums;

public enum BasePageId {


}
