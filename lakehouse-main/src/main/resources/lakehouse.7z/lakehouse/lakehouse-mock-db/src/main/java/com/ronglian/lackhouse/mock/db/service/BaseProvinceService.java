package com.ronglian.lackhouse.mock.db.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.ronglian.lackhouse.mock.db.bean.BaseProvince;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zc
 * @since 2020-02-23
 */
public interface BaseProvinceService extends IService<BaseProvince> {

}
