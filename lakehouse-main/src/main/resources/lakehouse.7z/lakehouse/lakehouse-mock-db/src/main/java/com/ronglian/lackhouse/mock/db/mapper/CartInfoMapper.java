package com.ronglian.lackhouse.mock.db.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ronglian.lackhouse.mock.db.bean.CartInfo;

/**
 * <p>
 * 购物车表 用户登录系统时更新冗余 Mapper 接口
 * </p>
 *
 * @author zc
 * @since 2020-02-24
 */
public interface CartInfoMapper extends BaseMapper<CartInfo> {

}
