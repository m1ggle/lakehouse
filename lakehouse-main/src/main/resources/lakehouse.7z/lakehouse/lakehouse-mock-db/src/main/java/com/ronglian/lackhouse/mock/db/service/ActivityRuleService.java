package com.ronglian.lackhouse.mock.db.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.ronglian.lackhouse.mock.db.bean.ActivityRule;

/**
 * <p>
 * 优惠规则 服务类
 * </p>
 *
 * @author zhangchen
 * @since 2020-02-25
 */
public interface ActivityRuleService extends IService<ActivityRule> {

}
